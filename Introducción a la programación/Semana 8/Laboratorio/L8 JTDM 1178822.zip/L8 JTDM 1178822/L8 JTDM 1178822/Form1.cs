﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_JTDM_1178822
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = int.Parse(textBox2.Text);
            int suma = 0;
            for (int i = 0; i <= n; i++)
            {
                suma = suma + i;
            }
            label3.Text=Convert.ToString(suma);
               

           
           
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {
            string m = "";
            for(int i =1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++) { 
                if (j <= 9) 
                {
                    m = m + Convert.ToString(i * j)+"\t";
                }
                if(j == 10)
                {
                        m = m + Convert.ToString(i * j) + "\n";
                }
                }
                label4.Text = Convert.ToString(m);
            }
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int numperfe = int.Parse(textBox1.Text);
            int suma = 0;
            for (int i = 1; i < numperfe; i++)
            {
                if (numperfe % i == 0)
                {
                    suma = suma + i;
                }

            }


            if (suma == numperfe)
            {
                label6.Text = "Ingreso un número perfecto";
            }
            else
            {
                label6.Text = "Ingreso un número que no es perfecto";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selec = comboBox1.SelectedIndex;
            switch(selec)
            {
                case 0:
                    tabControl1.SelectedIndex = 0;
                    break;
                case 1:
                    tabControl1.SelectedIndex = 1;
                    break;
                case 2:
                    tabControl1.SelectedIndex = 2;
                    break;

                    
            }
        }
    }
}
