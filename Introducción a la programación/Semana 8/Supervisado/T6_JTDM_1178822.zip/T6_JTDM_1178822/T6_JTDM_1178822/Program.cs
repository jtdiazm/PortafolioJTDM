﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T6_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int mes;
            int dia;
            int año;
            Console.WriteLine("¿Cuál es su año de nacimiento?");
            año= int.Parse(Console.ReadLine());
            Console.WriteLine("¿Cuál es su mes de nacimiento? 1-12");
            mes = int.Parse(Console.ReadLine());
            Console.WriteLine("¿Cuál es el día de su nacimiento?");
            dia = int.Parse(Console.ReadLine());

            switch (mes)
            {
                case 1:
                    if (dia < 20)
                    {
                        Console.WriteLine("Su signo zodiacal es: Capricornio");
                    }
                    else if (dia > 19)
                    {
                        Console.WriteLine("Su signo zodiacal es: Acuario");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 2:
                    if (dia < 19)
                    {
                        Console.WriteLine("Su signo zodiacal es: Acuario");
                    }
                    else if (dia > 18)
                    {
                        Console.WriteLine("Su signo zodiacal es: Piscis");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 3:
                    if (dia < 21)
                    {
                        Console.WriteLine("Su signo zodiacal es: Piscis");
                    }
                    else if (dia > 20)
                    {
                        Console.WriteLine("Su signo zodiacal es: Aries");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 4:
                    if (dia < 20)
                    {
                        Console.WriteLine("Su signo zodiacal es: Aries");
                    }
                    else if (dia > 21)
                    {
                        Console.WriteLine("Su signo zodiacal es: Tauro");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 5:
                    if (dia < 21)
                    {
                        Console.WriteLine("Su signo zodiacal es: Tauro");
                    }
                    else if (dia > 20)
                    {
                        Console.WriteLine("Su signo zodiacal es: Géminis");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 6:
                    if (dia < 21)
                    {
                        Console.WriteLine("Su signo zodiacal es: Géminis");
                    }
                    else if (dia > 20)
                    {
                        Console.WriteLine("Su signo zodiacal es: Cancer");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 7:
                    if (dia < 23)
                    {
                        Console.WriteLine("Su signo zodiacal es: Cancer");
                    }
                    else if (dia > 22)
                    {
                        Console.WriteLine("Su signo zodiacal es: Leo");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 8:
                    if (dia < 23)
                    {
                        Console.WriteLine("Su signo zodiacal es: Leo");
                    }
                    else if (dia > 22)
                    {
                        Console.WriteLine("Su signo zodical es: Virgo");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 9:
                    if (dia < 23)
                    {
                        Console.WriteLine("Su signo zodiacal es: Virgo");
                    }
                    else if (dia > 22)
                    {
                        Console.WriteLine("Su signo zodiacal es: Libra");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 10:
                    if (dia < 23)
                    {
                        Console.WriteLine("Su signo zodiacal es: libra");
                    }
                    else if (dia > 22)
                    {
                        Console.WriteLine("Su signo zodiacal es: Escorpio");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 11:
                    if (dia < 22)
                    {
                        Console.WriteLine("Su signo zodiacal es: Escorpio");
                    }
                    else if (dia > 21)
                    {
                        Console.WriteLine("Su signo zodiacal es: Sagitario");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                case 12:
                    if (dia < 22)
                    {
                        Console.WriteLine("Su signo zodiacal es: Sagitario");
                    }
                    else if (dia > 21)
                    {
                        Console.WriteLine("Su signo zodiacal es: Capricornio");
                    }
                    else
                        Console.WriteLine("SU NUMERO DE DIA ESTÁ ENTRE EL LIMITE");
                    break;

                default:
                    Console.WriteLine("ERROR: SU NUMERO DE MES NO ESTÁ EN EL LIMITE");
                    break;
            }
            Console.ReadKey();
        }
    }
}
