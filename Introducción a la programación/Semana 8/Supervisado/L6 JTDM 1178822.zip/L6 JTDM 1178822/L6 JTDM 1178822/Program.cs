﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 01
            Console.WriteLine("Ejercicio 1");

            int mes;
                Console.WriteLine("Ingrese un número del 1 al 12 según el mes que solicite");
                mes=int.Parse(Console.ReadLine());
            switch(mes)
            {
                case 1:
                    Console.WriteLine("MES: Enero");
                    break;
                case 2:
                    Console.WriteLine("MES: Febrero");
                    break;
                case 3:
                    Console.WriteLine("MES: Marzo");
                    break;
                case 4:
                    Console.WriteLine("MES: Abril");
                    break;
                case 5:
                    Console.WriteLine("MES: Mayo");
                    break;
                case 6:
                    Console.WriteLine("MES: Junio");
                    break;
                case 7:
                    Console.WriteLine("MES: Julio");
                    break;
                case 8:
                    Console.WriteLine("MES: Agosto");
                    break;
                case 9:
                    Console.WriteLine("MES: Septiembre");
                    break;
                case 10:
                    Console.WriteLine("MES: Octubre");
                    break;
                case 11:
                    Console.WriteLine("MES: Noviembre");
                    break;
                case 12:
                    Console.WriteLine("MES: Diciembre");
                    break;
                default:
                    Console.WriteLine("Error el número a ingresar debe estar contenido en 1 y 12");
                    break;

            }

            //Ejercicio 02
            Console.WriteLine("Ejercicio 2, identificaer el numero mayor");
            int numero1;
                Console.WriteLine("Escriba su primer número:");
                numero1 = int.Parse(Console.ReadLine());

            int numero2;
                Console.WriteLine("Escriba su segundo número:");
                numero2 = int.Parse(Console.ReadLine());

            int numero3;
                Console.WriteLine("Escriba su tercer número:");
                numero3 = int.Parse(Console.ReadLine());

            if (numero1 > numero2)
            {
                //primera condición
                if (numero1 > numero3)
                {
                    Console.WriteLine("RESULTADO: "+numero1);
                }
                else
                {
                    if (numero1 == numero3)
                    {
                        Console.WriteLine("RESULTADO: " + numero3);
                    }
                    else
                    {
                        Console.WriteLine("RESULTADO: " + numero3);
                    }
                }
            }
            else
            {
                if (numero1 == numero2)
                {
                    if (numero1 > numero3)
                    {
                        Console.WriteLine("RESULTADO: " + numero1);
                    }
                    else
                    {
                        if (numero1 == numero3)
                        {
                            Console.WriteLine("RESULTADO: " + numero1);
                        }
                        else
                        {
                            Console.WriteLine("RESULTADO: " + numero3);
                        }
                    }
                }
                else
                {
                    if (numero2 > numero3)
                    {
                        Console.WriteLine("RESULTADO: " + numero2);

                    }
                    else
                    {
                        if (numero2 == numero3)
                        {
                            Console.WriteLine("RESULTADO:" + numero3);
                        }
                        else
                        {
                            Console.WriteLine("RESULTADO: " + numero3);
                        }
                    }

                }

                
            }

            Console.ReadKey();

        }
    }
}
