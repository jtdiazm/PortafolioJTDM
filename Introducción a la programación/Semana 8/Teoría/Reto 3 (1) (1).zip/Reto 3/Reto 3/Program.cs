﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variables
            int letra;
            //Proceso
            Console.WriteLine("Escriba el número correspondiente a la vocal que necesita");
            Console.WriteLine("a=1 e=2 i=3 o=4 u=5");
            letra = int.Parse(Console.ReadLine());
            //letra u
            if (letra == 5)
            {
                for (int x = 0; x < 9; x++)
                {
                    Console.WriteLine("X               X");
                }
                Console.WriteLine("X X X X X X X X X");
            }
            //letra a
            if (letra == 1) 
            {
                Console.WriteLine("x x x x x x x x x");

                for (int x = 0; x < 3; x++)
                {
                    Console.WriteLine("x               x");
                }
                Console.WriteLine("x x x x x x x x x");
                for (int x = 0; x < 5; x++)
                {
                    Console.WriteLine("x               x");
                }
            }
            //letra e
            if (letra == 2)
            {
                Console.WriteLine("X X X X X X X X X");

                for (int y = 0; y < 4; y++)
                {
                    Console.WriteLine("X");
                }
                Console.WriteLine("X X X X X X X X X");
                for (int y = 0; y < 3; y++)
                {
                    Console.WriteLine("X");
                }
                Console.WriteLine("X X X X X X X X X");
                Console.WriteLine(" ");
            }
            if(letra == 3)
            {
                Console.WriteLine("X X X X X X X X X");
                for (int y = 0; y < 8; y++)
                {
                    Console.WriteLine("        X");
                }
                Console.WriteLine("X X X X X X X X X");
            }
            if (letra == 4)
            {
                Console.WriteLine("                               ");
                Console.WriteLine("x x x x x x x x x");
                for (int x = 0; x < 8; x++)
                {
                    Console.WriteLine("x               x");
                }
                Console.WriteLine("x x x x x x x x x");
            }
            Console.ReadKey();

        }
    }
}
