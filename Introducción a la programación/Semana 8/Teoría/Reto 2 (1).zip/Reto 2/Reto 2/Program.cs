﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Jorge Tulio Díaz Monterroso 1178822; Gerson Adrián Tobar 1067022; Andrei Lucero 1155622
            Console.WriteLine("X X X X X X X X X");

            for (int y = 0; y < 4; y++)
            {
                Console.WriteLine("X");
            }
            Console.WriteLine("X X X X X X X X X");
            for (int y = 0; y < 3; y++)
            {
                Console.WriteLine("X");
            }
            Console.WriteLine("X X X X X X X X X");
            Console.WriteLine(" ");

            //letra i
            Console.WriteLine("X X X X X X X X X");
            for (int y = 0; y < 8; y++)
            {
                Console.WriteLine("        X");
            }
            Console.WriteLine("X X X X X X X X X");
            Console.ReadKey();
        }

      
    }
 
}
