﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //A
            Console.WriteLine("x x x x x x x x x");

            for (int x = 0; x<3; x++)
            {
                Console.WriteLine("x               x");
                    }
            Console.WriteLine("x x x x x x x x x");
            for (int x = 0; x<5; x++)
            {
                Console.WriteLine("x               x");
            }
            //O
            Console.WriteLine("                               ");
            Console.WriteLine("x x x x x x x x x");
            for (int x = 0; x<8; x++)
            {
                Console.WriteLine("x               x");
            }
            Console.WriteLine("x x x x x x x x x");

            Console.ReadKey();
        }
    }
}
