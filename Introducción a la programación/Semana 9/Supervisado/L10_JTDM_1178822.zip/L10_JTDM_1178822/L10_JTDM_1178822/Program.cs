﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Laboratorio 10");
            Console.WriteLine("Escriba el radio del círculo:");
            double radioIngresado = double.Parse(Console.ReadLine());

            //Varibables
            double perimetroCalculado = 0;
            double areaCalculado = 0;
            double volumenCalculado = 0;

            //Objeto de tipo circulo
            ciruculo objCirculo = new ciruculo(radioIngresado);

            //Guardar calculos:
            objCirculo.CalculadoraGeometria(ref perimetroCalculado, ref areaCalculado, ref volumenCalculado);

            //Enseñar resultados:
            Console.WriteLine("Perímetro: " + perimetroCalculado);
            Console.WriteLine("Área: " + areaCalculado);
            Console.WriteLine("Volumen: " + volumenCalculado);

            Console.ReadKey();





        }
    }
    class ciruculo
    {
        private double radio;

        //Constructor
        public ciruculo(double Radio)
        {
            radio = Radio;
        }

        //Mëtodos
        private double ObtenerPerimetro()
        {
            double perimetro = 2 * Math.PI * radio;
            return perimetro;
        }
        private double ObtenerArea()
        {
            double area = Math.PI * Math.Pow(radio, 2);
            return area;
        }
        private double ObtenerVolumen()
        {
            double volumen = (4 * Math.PI * Math.Pow(radio, 3)) / 3;
            return volumen;
        }
        public void CalculadoraGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            unPerimetro = ObtenerPerimetro();
            unArea = ObtenerArea();
            unVolumen = ObtenerVolumen();
        }
    }
}
