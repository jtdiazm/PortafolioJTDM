using L9_JTDM_1178822;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace L9_JTDM_1178822
{
    public partial class Form1 : Form
    {
        Automovil miAutomovil = new Automovil();
        public Form1()
        {
            InitializeComponent();
        }


        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
            button2.Enabled = true;
            button3.Enabled = true;
            string marca;
            int modelo;
            double precio; 
            double tipoCambio;
            modelo = Convert.ToInt16(textBox1.Text);
            precio = Convert.ToDouble(textBox2.Text);
            marca = textBox3.Text;
            tipoCambio = Convert.ToDouble(textBox4.Text);
            miAutomovil.DefinirMarca(marca);
            miAutomovil.DefinirModelo(modelo);
            miAutomovil.DefinirPrecio(precio);
            miAutomovil.DefinirTipoCambio(tipoCambio);
            textBox6.Text = miAutomovil.MostrarInformacion();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double descuento;
            descuento = Convert.ToDouble(textBox5.Text);
            miAutomovil.AplicarDescuento(descuento);
            Limpiar();
            textBox6.Text = miAutomovil.MostrarInformacion();
        }
        public void Limpiar()
        {
            textBox6.Text = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Limpiar();
            miAutomovil.CambiarDisponibilidad();
            textBox6.Text = miAutomovil.MostrarInformacion();
        }

    }
}