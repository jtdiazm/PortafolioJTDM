﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_JTDM_1178822
{
    internal class Automovil
    {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public Automovil()
        {
            this.modelo = 2019;
            this.precio = 10000;
            this.marca = "";
            this.disponible = false;
            this.tipoCambioDolar = 7.50;
            this.descuentoAplicado = 0;

        }
        public void DefinirModelo(int unModelo)
        {
            this.modelo = unModelo;
        }
        public void DefinirPrecio(double unPrecio)
        {
            this.precio = unPrecio;
        }
        public void DefinirMarca(string unaMarca)
        {
            this.marca = unaMarca;
        }
        public void DefinirTipoCambio(double unTipodecambio)
        {
            this.tipoCambioDolar = unTipodecambio;
        }
        public double PrecioDolares()
        {
            double precioDolar = 0;
            precioDolar = this.precio / this.tipoCambioDolar;
            return precioDolar;
        }    
        public void CambiarDisponibilidad()
        {
           if (this.disponible==true)
            {
                this.disponible = false;
            }
           else
            {
                this.disponible = true;
            }
      

        }
        public string MostrarDisponibilidad()
        {
            string dis;
            if (this.disponible==true)
            {
                dis = "Disponible";

            }
            else
            {
                dis = "No se enceuntra disponible actualmente";
            }
            return dis;


        }
        public string MostrarInformacion()
        {
            string texto = "Marca: " + this.marca + Environment.NewLine + "Modelo: " + this.modelo + Environment.NewLine + "Precio de venta Q:" + this.precio + Environment.NewLine + "Precio en dolares $:" + PrecioDolares() + Environment.NewLine + MostrarDisponibilidad();

            return texto;
        }
        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            this.precio = this.precio - descuentoAplicado;
            DefinirPrecio(this.precio);
        }

    }
}
