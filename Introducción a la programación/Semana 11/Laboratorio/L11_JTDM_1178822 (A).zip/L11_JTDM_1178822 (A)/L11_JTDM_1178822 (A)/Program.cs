﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_JTDM_1178822__A_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Sección 1
            double[] promedio1 = new double[4];
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("Ingrese el promedio del estudiante No." + (i + 1) + " de la Sección 1:");
                promedio1[i] = double.Parse(Console.ReadLine());

            }

            //Sección 2
            double[] promedio2 = new double[4];
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("Ingrese el promedio del estudiante No." + (i + 1) + " de la Sección 2:");
                promedio2[i] = double.Parse(Console.ReadLine());

            }
            int x = 0;
            int y = 0;
            double pora1 = 0;
            double desa1 = 0;
            for (int i = 0; i < 4; i++)
            {
                if (promedio1[i] >= 65)
                {
                    x++;

                }
                else
                {
                    y++;
                }
            }
            pora1 = (Convert.ToDouble(x) / 4) * 100;
            Console.WriteLine("El porcentaje de alumnos aprobados de la sección 1: " + pora1 + "%");

            desa1 = (Convert.ToDouble(y) / 4) * 100;
            Console.WriteLine("El porcentaje de alumnos reprobados de la sección 1: " + desa1 + "%");

            int z = 0;
            int a = 0;
            double pora2 = 0;
            double desa2 = 0;
            for (int i = 0; i < 4; i++)
            {
                if (promedio2[i] >= 65)
                {
                    z++;

                }
                else
                {
                    a++;
                }
            }
            pora2 = (Convert.ToDouble(x) / 4) * 100;
            Console.WriteLine("El porcentaje de alumnos aprobados de la sección 2: " + pora2 + "%");

            desa2 = (Convert.ToDouble(y) / 4) * 100;
            Console.WriteLine("El porcentaje de alumnos reporbados de la sección 2: " + desa2 + "%");

            double porat = 0;
            porat = (((Convert.ToDouble(x) + Convert.ToDouble(z)) / 8) * 100);
            Console.WriteLine("El porcentraje de alumnos aprobados de las dos secciones es: " + porat + "%");

            double desat = 0;
            desat = (((Convert.ToDouble(y) + Convert.ToDouble(a)) / 8) * 100);
            Console.WriteLine("El porcentraje de alumnos reprobados de las dos secciones es: " + desat + "%");

            double proms1 = 0;
            double sumas1 = 0;
            for (int i = 0; i < 4; i++)
            {
                sumas1 = sumas1 + promedio1[i];
                proms1 = sumas1 / 4;
            }
            Console.WriteLine("EL promedio de la sección 1 es: " + proms1);

            double proms2 = 0;
            double sumas2 = 0;
            for (int i = 0; i < 4; i++)
            {
                sumas2 = sumas2 + promedio2[i];
                proms2 = sumas2 / 4;
            }
            Console.WriteLine("EL promedio de la sección 2 es: " + proms2);
            double promt = 0;
            promt = (sumas1 + sumas2) / 8;
            Console.WriteLine("El promedio de las dos secciones es: " + promt);

            int j = 0;
            int k = 0;
            int m = 0;
            int t = 0;
            int cont90 = 0;
            int cont75 = 0;

            for (int i = 0; i < 4; i++)
            {
                if (promedio1[i] > 90)
                {
                    j++;
                }
                if (promedio2[i] > 90)
                {
                    k++;
                }
                if (promedio1[i] < 75)
                {
                    m++;
                }
                if (promedio1[i] < 75)
                {
                    t++;
                }
            }
            cont90 = j + k;
            cont75=m + t;
            Console.WriteLine("La cantidad de estudiantes con un promedio mayor a 90 es: " + cont90);
            Console.WriteLine("La cantidad de estudiantes con un promedio menor a 75 es: " + cont75);
            Console.ReadKey();

        }
    }
}
