﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            Console.WriteLine("ingrese el número de enteros que quiere sumar: ");
            n= int.Parse(Console.ReadLine());

            int[] v;
            v = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Ingrese el dato " + (i) + ": ");
                v[i] = int.Parse(Console.ReadLine());

            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Número " + (i) + ": " + v[i]);
            }
            int suma = 0;
            for (int i = 0; i < n; i++)
            {
                suma=suma + v[i];
            }
            Console.WriteLine("La suma total de los valores es: " + suma);
            Console.WriteLine("La longitud del arreglo es:" + n);

            int sumap = 0;
            int sumai = 0;
            for (int i = 0; i < n; i++)
            {
                if (i % 2 == 0)
                {
                    sumap = sumap + v[i];
                }
                else
                {
                    sumai = sumai + v[i];
                }
            }
            Console.WriteLine("La suma de las posiciones pares es: " + sumap);
            Console.WriteLine("La suma de las posiciones impares es: " + sumai);


            Console.ReadKey();

        }
    }
}
