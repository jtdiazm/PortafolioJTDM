﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_3_18_10
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] adultos = new int[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("¿Cuántos adultos hay en el nivel " + (i + 1) + "?");
                adultos[i] = int.Parse(Console.ReadLine());
            }
            int[] nino = new int[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("¿Cuántos niños hay en el nivel " + (i + 1) + "?");
                nino[i] = int.Parse(Console.ReadLine());
            }
            string[] encargado = new string[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese el nombre del encargado del nivel " + (i + 1));
                encargado[i] = Console.ReadLine();
            }

            string[] nivel = new string[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(" En el nivel " + (i + 1) + " hay: " + (adultos[i] + nino[i]) + " personas.");
                Console.WriteLine(nivel[i]);
            }

            
            int min = adultos[0] + nino[0];
            int imin = 0 ;
            string a = "";
            for (int i = 0; i < 5; i++)
            {
                if (adultos[i] + nino[i] > min)
                {
                    a = encargado[i];
                    imin = i;
                }
            }
            Console.WriteLine("El encargado con el nivel con más personas es " + a);
           

            Console.ReadKey();

            
        }
    }
}
