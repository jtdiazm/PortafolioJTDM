﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Escriba su nombre");
            String sNombre = Console.ReadLine();
            Console.WriteLine("Escriba su edad");
            String sEdad = Console.ReadLine();
            Console.WriteLine("Escriba su carrera");
            String sCarrera = Console.ReadLine();
            Console.WriteLine("Escriba su Carné");
            String sCarné = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("Nombre: " + sNombre);
            Console.WriteLine("Edad: " + sEdad);
            Console.WriteLine("Carrera: " + sCarrera);
            Console.WriteLine("Carné: " + sCarné);
            Console.WriteLine("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ". Mi número de carné es: " + sCarné);
            Console.ReadKey();    
                }
    }
}
