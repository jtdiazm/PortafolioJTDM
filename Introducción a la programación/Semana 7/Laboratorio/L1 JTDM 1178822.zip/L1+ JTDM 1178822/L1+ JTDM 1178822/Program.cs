﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1__JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo soy Jorge");
            Console.ReadKey();

            //Parte número 2
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy Jorge");

            /* Write se usará para imprimir datos sin imprimirla nueva línea, en cambio Writeline se usar para imprimir datos junto con la impresión de la nueva línea */

            Console.Write("Hola Mundo");
            Console.Write("soy Jorge");
            Console.ReadKey();

            //Parte número 3
            Console.WriteLine("Ingrese su nombre:  ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola mundo");
            Console.WriteLine("soy " + Nombre);

            /* COMENTARIOS */

            Console.Write("Hola Mundo ");
            Console.Write("soy " + Nombre);
            Console.ReadKey();
        }
    }
}
