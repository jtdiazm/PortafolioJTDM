﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace L10_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string usua;
            string pasw;
            bool usuacorrect;
            int cont = 0;
           
            do
            {
                Console.WriteLine("Ingrese el usuario");
                usua = (Console.ReadLine());  
                Console.WriteLine("Ingrese la contraseña");
                pasw = (Console.ReadLine());
                usuacorrect = Login(usua, pasw);
                if (usuacorrect == true)
                {
                    Console.WriteLine("Credenciales correctas, bienvenido Usuario 1");
                    cont = 3;

                }
                else
                {
                    cont++;
                    Console.WriteLine("Credenciales incorrectas, intente de nuevo");
                    Console.WriteLine("Número de intentos: " + cont);
                    Console.WriteLine("Ya no quedan más intentos");
                }
            }
            while (cont<3);
            Console.ReadKey();


        }
        static bool Login(string username, string pasword)
        {

            if (username== "Usuario1" & pasword == "asdasd")
            {
                return true;
            }
            else
                return false;

            

            
        }

    }
}
