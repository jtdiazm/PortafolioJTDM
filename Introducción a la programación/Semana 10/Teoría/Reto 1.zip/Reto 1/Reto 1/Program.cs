﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio de su circulo para obtener el perímetro");
            int radio = Convert.ToInt32(Console.ReadLine());
            double resultado = PerimetroCirculo(radio);
            Console.WriteLine("El perímetro es: " + Convert.ToString(resultado));
            Console.ReadKey();
        }
        static double PerimetroCirculo(int radio)
        {
            double resultado = 0;
            int diametro = 2 * radio;
            double pi = 3.1416;

            resultado = diametro * pi;

            return resultado;
        }
    }
}
