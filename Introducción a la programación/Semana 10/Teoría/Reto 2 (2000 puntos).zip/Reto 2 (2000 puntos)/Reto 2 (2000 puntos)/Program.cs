﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_2__2000_puntos_
{
    internal class Program
    {
        //Grupo Jorge Díaz, Adrián Tobar, Andrei Lucero
        static void Main(string[] args)
        {
            Suma();
        }

        static void Suma()
        {
            bool correcta = false;
            
            do
            {
                Console.WriteLine("Ingrese el primer valor");
                string num1 = Console.ReadLine();
                Console.WriteLine("Ingrese el segundo valor");
                string num2 = Console.ReadLine();
                Console.WriteLine("Ingrese el resultado");
                string resultado = Console.ReadLine();
                double numero1 = Convert.ToDouble(num1);
                double numero2 = Convert.ToDouble(num2);
                double resultadoFinal = Convert.ToDouble(resultado);
                if(numero1 + numero2 != resultadoFinal)
                {
                    correcta = false;
                    Console.WriteLine("Tu operación es incorrecta, presiona enter para intentarlo nuevamente");
                    Console.ReadKey();
                }
                else
                {
                    correcta = true;
                    Console.WriteLine("Tu operación es correcta: " + num1 + "+" + num2 + "=" + resultado);
                    Console.ReadKey();
                }

            } while (correcta == false);
            
        }
    }
}
