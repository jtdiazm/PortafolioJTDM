﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace L12_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] elementos = new int [14];
            for (int i = 0; i < 14; i++)
            {
                Console.WriteLine("Ingrese el elemento " + (i+1) + ":");
                elementos[i] = int.Parse(Console.ReadLine());

            }
            int suma = 0;
            for (int i = 0; i < 14; i++)
            {
                suma=suma+ elementos[i];  
            }
            Console.WriteLine("La suma de los elementos es: " + suma);

            int cont = 0;
            for (int i = 0; i < 14; i++)
            {
                if (elementos[i] > 12)
                {
                    cont++;

                }
            }
            Console.Write("La cantidad de números mayores al valor (12) es: " + cont);
            Console.WriteLine(" ");

            double porcentaje = 0;
            porcentaje = (Convert.ToDouble(cont)/14)*100;
            Console.WriteLine("El porcentaje de números mayores que el valor (12) es: " + porcentaje + "%");
            Console.ReadKey();
        }

    }
}
