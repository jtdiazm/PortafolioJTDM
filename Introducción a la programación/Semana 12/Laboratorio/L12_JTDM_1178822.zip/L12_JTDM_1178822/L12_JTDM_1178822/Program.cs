﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace L12_JTDM_1178822
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double[,] matriz1 = new double[4, 5];
            for(int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine("Ingrese valor para la primera matriz:");
                    matriz1[i, j] = double.Parse(Console.ReadLine());

                }
            }

            double suma = 0;
            double promedio = 0;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    suma=suma+matriz1[i, j];
                }
            }
            promedio = suma / 20;
            
            Console.WriteLine("La suma de la matriz es: " + suma);
            Console.WriteLine("El promedio de la matriz es: " + promedio);

            double[,] matriz2 = new double[4, 5];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine("Ingrese valor para la segunda matriz: ");
                    matriz2[i, j] = double.Parse(Console.ReadLine());

                }
            }

            double[,] resultado = new double[4, 5];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    resultado[i, j] = matriz1[i,j] + matriz2[i,j];
                }
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(resultado[i, j] + " ");
                }
                Console.WriteLine();
            }
           
  
            Console.ReadKey();
        }
    }
}
