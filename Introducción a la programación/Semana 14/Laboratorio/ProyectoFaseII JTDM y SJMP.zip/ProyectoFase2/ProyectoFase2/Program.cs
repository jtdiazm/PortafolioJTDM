﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFase2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Variables
            string opcion = "";
            int TemperaturaPromedio;
            int HumedadPromedio;
            bool CalefaccionEncendiad = false;
            bool VentilacionEncendida = false;
            bool IluminacionEncendida = false;

            //variable de tiempo para ejecución automática
            DateTime ejecucionProgramada = new DateTime();

            //Variables de máximos y mínimos de temperatura
            int maximaTemperatura = 22;
            int minimaTemperatura = 18;

            //Se crean los objetos tipo habitación en los cuales se incluirán los datos de cada habitación. Se inicializan las temperaturas y humedades con 0 al igual que los sistemas
            Cuarto sala = new Cuarto(0, 80, false, false, false, "Sala" ,0);
            Cuarto cocina = new Cuarto(0, 0, false, false, false, "Cocina" ,0);
            Cuarto habitacion1 = new Cuarto(0, 75, false, false, false, "Habitacion 1" ,0);
            Cuarto habitacion2 = new Cuarto(0, 0, false, false, false, "Habitacion 2" ,0);
            Cuarto habitacion3 = new Cuarto(0, 0, false, false, false, "Habitacion 3" ,0);
            //se crea un vector tipo casa el cual incluirá los objetos tipo habitación
            Cuarto[] Casa = new Cuarto[5];

            //Se agregan los objetos tipo habitación al vector tipo casa
            Casa[0] = sala;
            Casa[1] = cocina;
            Casa[2] = habitacion1;
            Casa[3] = habitacion2;
            Casa[4] = habitacion3;

            //Se inicia clase para control del sistema
            ControlSistemas Control = new ControlSistemas();
            //Crear clases para mostrar menu
            Calefaccion calefaccion = new Calefaccion();
            Ventilacion ventilacion = new Ventilacion();
            Iluminacion iluminacion = new Iluminacion();
            Panel panel = new Panel();

            //Se muestra el menú inicial
            do
            {
                //Se lee información del sistema
                TemperaturaPromedio = Control.TemperaturaPromedio(Casa);
                HumedadPromedio = Control.HumedadPromedio(Casa);
                CalefaccionEncendiad = Control.CalefaccionEncendida(Casa);
                VentilacionEncendida = Control.VentilacionEncendida(Casa);
                IluminacionEncendida = Control.IluminacionEncendida(Casa);
                
                
                Console.Clear();
                Console.WriteLine(@",--.   ,--.                                         ,--.              ,--.               ,--. ");
                Console.WriteLine(@"|   `.'   | ,---. ,--,--, ,--.,--.     ,---. ,--.--.`--',--,--,  ,---.`--' ,---.  ,--,--.|  | ");
                Console.WriteLine(@"|  |'.'|  || .-. :|      \|  ||  |    | .-. ||  .--',--.|      \| .--',--.| .-. |' ,-.  ||  | ");
                Console.WriteLine(@"|  |   |  |\   --.|  ||  |'  ''  '    | '-' '|  |   |  ||  ||  |\ `--.|  || '-' '\ '-'  ||  | ");
                Console.WriteLine(@"`--'   `--' `----'`--''--' `----'     |  |-' `--'   `--'`--''--' `---'`--'|  |-'  `--`--'`--' ");
                Console.WriteLine(@"                                      `--'                                `--'                ");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Elija una opción");
                Console.WriteLine("1. Calefacción");
                Console.WriteLine("2. Ventilación");
                Console.WriteLine("3. Iluminación");
                Console.WriteLine("4. Panel de control");
                Console.WriteLine("5. Salir");
                if (ejecucionProgramada == null)
                {
                    Console.WriteLine("Aún no se ha programado la ventilación automática");
                }
                else
                {
                    if (ejecucionProgramada.Minute == DateTime.Now.Minute && ejecucionProgramada.Hour == DateTime.Now.Hour)
                    {
                        Console.Beep(); //Se alerta que se hará una ejecución programada automática
                        Console.WriteLine("Ejecutando la ventilación automática según la hora programada " + ejecucionProgramada.ToString("HH:mm"));

                        //para cada cuarto de la casa se realiza la ejecución automática
                        for (int i = 0; i < Casa.Length; i++)
                        {
                            ventilacion.VentilacionAutomatica(Casa[i]);

                        }
                        Console.WriteLine("Ejecución automática finalizada");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                    }
                }
                opcion = Console.ReadLine();
                switch (opcion)
                {
                    case "1":
                        //Se manda a llamar el menú de la calefaccion
                        calefaccion.MenuCalefaccion(Casa, maximaTemperatura, minimaTemperatura);
                        //Se pone nula la opción del menú
                        opcion = null;
                        break;
                    case "2":
                        //Se manda a llamar el menú de la ventilación
                        ventilacion.MenuVentilacion(Casa);
                        //Se pone nula la opción del menú
                        opcion = null;
                        break;
                    case "3":
                        //Se manda a llamar el menú de la ventilación
                        iluminacion.MenuIluminacion(Casa);
                        //Se pone nula la opción del menú
                        opcion = null;
                        break;
                    case "4":
                        panel.MenuPanel(Casa, ref ejecucionProgramada, ref maximaTemperatura, ref minimaTemperatura);
                        break;
                    case "5":
                        Console.WriteLine("Esperamos que vuelva pronto");
                        break;
                    default:
                        Console.WriteLine("Opción no válida");
                        break;
                }
            } while (opcion != "5");
            

        }
    }
    //Muestra el panel de control de la casa
    public class Panel
    {
        public void MenuPanel(Cuarto[] Casa, ref DateTime FechaAutomatica, ref int MaxTemp, ref int MinTemp)
        {
        //Se limpia la pantalla
        MenuPanelPrincipal:
            Console.Clear();
            Console.WriteLine(@" ____                  _       _         ____            _             _  ");
            Console.WriteLine(@"|  _ \ __ _ _ __   ___| |   __| | ___   / ___|___  _ __ | |_ _ __ ___ | | ");
            Console.WriteLine(@"| |_) / _` | '_ \ / _ \ |  / _` |/ _ \ | |   / _ \| '_ \| __| '__/ _ \| | ");
            Console.WriteLine(@"|  __/ (_| | | | |  __/ | | (_| |  __/ | |__| (_) | | | | |_| | | (_) | | ");
            Console.WriteLine(@"|_|   \__,_|_| |_|\___|_|  \__,_|\___|  \____\___/|_| |_|\__|_|  \___/|_| ");
            Console.WriteLine(@"                                                                          ");
            Console.WriteLine("");
            Console.WriteLine("Configuración actual");
            Console.WriteLine("Hora de Ventilación: " + FechaAutomatica.ToString("HH:mm"));
            Console.WriteLine("Temperatura Máxima: " + MaxTemp);
            Console.WriteLine("Temperatura Mínima: " + MinTemp);

            //Se instancia clase que controla el sistema para obtener la temperatura promedio
            ControlSistemas control = new ControlSistemas();

            Console.WriteLine("Temperatura promedio: " + control.TemperaturaPromedio(Casa) + "°C");
            Console.WriteLine("");
            Console.WriteLine("Información de Sistemas:");
            if (control.CalefaccionEncendida(Casa) == true)
            {
                Console.WriteLine("Calefacción: Encendida");
            }
            else
            {
                Console.WriteLine("Calefacción: Apagada");
            }
            if (control.VentilacionEncendida(Casa) == true)
            {
                Console.WriteLine("Ventilación: Encendida");
            }
            else
            {
                Console.WriteLine("Ventilación: Apagada");
            }
            if (control.IluminacionEncendida(Casa) == true)
            {
                Console.WriteLine("Iluminación: Encendida");
            }
            else
            {
                Console.WriteLine("Iluminación: Apagada");
            }
            Console.WriteLine("");
            Console.WriteLine("1. Configurar Hora de Ventilación");
            Console.WriteLine("2. Configurar Temperatura Máxima");
            Console.WriteLine("3. Configurar Temperatura Mínima");
            Console.WriteLine("4. Regresar al menú principal");

            string opción = Console.ReadLine();


            //dependiendo de la habitación elegida interactuar
            switch (opción)
            {
                case "1":
                ConfigurarHora:
                    Console.Clear();
                    Console.WriteLine("Ingrese la hora en formato 24 horas (HH:MM)");
                    string hora = Console.ReadLine();
                    try
                    {
                        FechaAutomatica = Convert.ToDateTime(hora);
                        Console.WriteLine("Hora de ventilación configurada correctamente");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto MenuPanelPrincipal;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Ocurrio un error al leer la hora, intente configurarla nuevamente");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto ConfigurarHora;
                        throw;
                    }
                    break;
                case "2":
                ConfigurarMax:
                    Console.Clear();
                    Console.WriteLine("Ingrese la temperatura máxima");
                    string max = Console.ReadLine();
                    try
                    {
                        MaxTemp = Convert.ToInt32(max);
                        Console.WriteLine("Temperatura máxima configurada correctamente");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto MenuPanelPrincipal;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Ocurrio un error al leer la temperatura, intente configurarla nuevamente");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto ConfigurarMax;
                        throw;
                    }
                    break;
                case "3":
                ConfigurarMin:
                    Console.Clear();
                    Console.WriteLine("Ingrese la temperatura mínima");
                    string min = Console.ReadLine();
                    try
                    {
                        MinTemp = Convert.ToInt32(min);
                        Console.WriteLine("Temperatura mínima configurada correctamente");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto MenuPanelPrincipal;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Ocurrio un error al leer la temperatura, intente configurarla nuevamente");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto ConfigurarMin;
                        throw;
                    }
                    break;
                case "4":
                    break;
                default:
                    Console.WriteLine("Opción no válida");
                    Console.WriteLine("Presione cualquier tecla para continuar");
                    Console.ReadKey();
                    goto MenuPanelPrincipal;
                    break;
            }
            Console.WriteLine("Presiona cualquier tecla para regresar al menú principal");
            Console.ReadKey();

        }

        //Validar la iluminacion del ambiente
    }
    //Clase que controla los sistemas de ventilación la casa
    public class Ventilacion
    {
        public void MenuVentilacion(Cuarto[] Casa)
        {
        //Se limpia la pantalla
        LeerCalefaccion:
            Console.Clear();
            Console.WriteLine(@"__     __         _   _ _            _             ");
            Console.WriteLine(@"\ \   / /__ _ __ | |_(_) | __ _  ___(_) ___  _ __  ");
            Console.WriteLine(@" \ \ / / _ \ '_ \| __| | |/ _` |/ __| |/ _ \| '_ \ ");
            Console.WriteLine(@"  \ V /  __/ | | | |_| | | (_| | (__| | (_) | | | |");
            Console.WriteLine(@"   \_/ \___|_| |_|\__|_|_|\__,_|\___|_|\___/|_| |_|");
            Console.WriteLine(@"                                                   ");
            Console.WriteLine("");
            Console.WriteLine("Humedad actual en los ambientes: ");
            for (int i = 0; i < Casa.Length; i++)
            {
                Console.WriteLine(Casa[i].Nombre + ": " + Casa[i].Humedad + "%");
            }
            Console.WriteLine("");
            //imprimir menú de selección de habitaciones
            Console.WriteLine("Ingrese el número de la habitación que desea modificar");
            for (int i = 0; i < Casa.Length; i++)
            {
                Console.WriteLine((i + 1) + "." + Casa[i].Nombre);
            }

            string Nohabitacion = Console.ReadLine();


            //dependiendo de la habitación elegida interactuar
            switch (Nohabitacion)
            {
                case "1":
                    ModificarVentilacion(Casa[0]);
                    break;
                case "2":
                    ModificarVentilacion(Casa[1]);
                    break;
                case "3":
                    ModificarVentilacion(Casa[2]);
                    break;
                case "4":
                    ModificarVentilacion(Casa[3]);
                    break;
                case "5":
                    ModificarVentilacion(Casa[4]);
                    break;
                default:
                    Console.WriteLine("Opción inválida, presiona cualquier tecla para ingresar una opción nuevamente");
                    Console.ReadKey();
                    goto LeerCalefaccion;
            }
            Console.WriteLine("Presiona cualquier tecla para regresar al menú principal");
            Console.ReadKey();

        }

        //Validar la temperatura del ambiente
         void ModificarVentilacion(Cuarto cuarto)
        {
            Console.WriteLine("Ingrese el porcentaje de humedad actual de la habitación");
            int humedad = Convert.ToInt32(Console.ReadLine());
            if (humedad > 70)
            {
                Console.WriteLine("La humedad esta Sobre el valor deseado, abriendo ventanas de ventilación. Humedad actual: " + humedad);
                Console.Beep();
                Console.WriteLine("Ventilando...");
                cuarto.VentilacionEncendida = true;
                cuarto.Humedad = 70;
            }
            else
            {
                Console.WriteLine("Se encuentra con la humedad recomendada");
                cuarto.VentilacionEncendida = false;
                cuarto.Humedad = humedad;
            }


        }

        public void VentilacionAutomatica(Cuarto cuarto)
        {
            if (cuarto.Humedad > 70)
            {
                Console.WriteLine("La habitación: " + cuarto.Nombre + " cuenta con humedad Sobre el valor deseado, abriendo ventanas de ventilación. Humedad actual: " + cuarto.Humedad);
                Console.Beep();
                Console.WriteLine("Ventilando...");
                cuarto.VentilacionEncendida = true;
                cuarto.Humedad = 70;
            }
            else
            {
                Console.WriteLine("La habitación: " + cuarto.Nombre + ". Se encuentra con la humedad recomendada");
                cuarto.VentilacionEncendida = false;
                cuarto.Humedad = cuarto.Humedad;
            }


        }
    }
    //Clase que funciona para ver todo respecto a la iluminación
    public class Iluminacion
    {
        public void MenuIluminacion(Cuarto[] Casa)
        {
        //Se limpia la pantalla
        LeerCalefaccion:
            Console.Clear();
            Console.WriteLine(@" ___ _                 _                  _             ");
            Console.WriteLine(@"|_ _| |_   _ _ __ ___ (_)_ __   __ _  ___(_) ___  _ __  ");
            Console.WriteLine(@" | || | | | | '_ ` _ \| | '_ \ / _` |/ __| |/ _ \| '_ \ ");
            Console.WriteLine(@" | || | |_| | | | | | | | | | | (_| | (__| | (_) | | | |");
            Console.WriteLine(@"|___|_|\__,_|_| |_| |_|_|_| |_|\__,_|\___|_|\___/|_| |_|");
            Console.WriteLine(@"                                                        ");
            Console.WriteLine("");
            Console.WriteLine("Iluminación actual en los ambientes: ");
            for (int i = 0; i < Casa.Length; i++)
            {
                if (Casa[i].IluminacionEncendida == false)
                {
                    Console.WriteLine(Casa[i].Nombre + "-> La iluminación está apagada");
                }
                else
                {
                    Console.WriteLine(Casa[i].Nombre + "-> La iluminación está encendida");
                }
            }
            Console.WriteLine("");
            //imprimir menú de selección de habitaciones
            Console.WriteLine("Ingrese el número de la habitación que desea modificar");
            for (int i = 0; i < Casa.Length; i++)
            {
                Console.WriteLine((i + 1) + "." + Casa[i].Nombre);
            }

            string Nohabitacion = Console.ReadLine();


            //dependiendo de la habitación elegida interactuar
            switch (Nohabitacion)
            {
                case "1":
                    ModificarIluminacion(Casa[0]);
                    break;
                case "2":
                    ModificarIluminacion(Casa[1]);
                    break;
                case "3":
                    ModificarIluminacion(Casa[2]);
                    break;
                case "4":
                    ModificarIluminacion(Casa[3]);
                    break;
                case "5":
                    ModificarIluminacion(Casa[4]);
                    break;
                default:
                    Console.WriteLine("Opción inválida, presiona cualquier tecla para ingresar una opción nuevamente");
                    Console.ReadKey();
                    goto LeerCalefaccion;
            }
            Console.WriteLine("Presiona cualquier tecla para regresar al menú principal");
            Console.ReadKey();

        }

        //Validar la iluminacion del ambiente
        void ModificarIluminacion(Cuarto cuarto)
        {
            Console.WriteLine("Ingrese la cantidad de personas presentes en la habitación");
            int personas = Convert.ToInt32(Console.ReadLine());
            if (personas > 0)
            {
                Console.WriteLine("Encendiendo luces, hay " + personas + " personas en la habitación");
                Console.Beep();
                cuarto.IluminacionEncendida = true;
                cuarto.Personas = personas;
            }
            else
            {
                Console.WriteLine("Apagando luces, no hay personas en la habitación");
                Console.Beep();
                cuarto.IluminacionEncendida = false;
                cuarto.Personas = 0;
            }


        }
    }
    //Clase que contiene los atributos de las habitaciones
    public class Cuarto
    {
        public int Temperatura { get; set; }
        public int Humedad { get; set; }
        public int Personas { get; set; }
        public bool VentilacionEncendida { get; set; }
        public bool IluminacionEncendida { get; set; }
        public bool CalefaccionEncendida { get; set; }
        public string Nombre { get; set; }

        //get set
        public Cuarto(int temperatura, int humedad, bool ventilacionEncendida, bool iluminacionEncendida, bool calefaccionEncendida, string nombre, int personas)
        {
            Temperatura = temperatura;
            Humedad = humedad;
            VentilacionEncendida = ventilacionEncendida;
            IluminacionEncendida = iluminacionEncendida;
            CalefaccionEncendida = calefaccionEncendida;
            Nombre = nombre;
            Personas = personas;
        }


    }
    //Clase para el control de sistemas internos, lleva todas las dependencias necesarias
    public class ControlSistemas
    {
        public DateTime horaAutomatizacion = DateTime.Now;
        //Validar si la temperatura de algún cuarto está encendida, entonces el sistema está funcionando
        public bool CalefaccionEncendida(Cuarto[] Casa)
        {
            bool encendido = false;
            for (int i = 0; i < Casa.Length; i++)
            {
                if (Casa[i].CalefaccionEncendida == true)
                {
                    encendido = true;
                }
            }
            return encendido;
        }
        //Validar si la ventilación de algún cuarto está encendida, entonces el sistema está funcionando
        public bool VentilacionEncendida(Cuarto[] Casa)
        {
            bool encendido = false;
            for (int i = 0; i < Casa.Length; i++)
            {
                if (Casa[i].VentilacionEncendida == true)
                {
                    encendido = true;
                }
            }
            return encendido;
        }
        //Validar si la iluminación de algún cuarto está encendida, entonces el sistema está funcionando
        public bool IluminacionEncendida(Cuarto[] Casa)
        {
            bool encendido = false;
            for (int i = 0; i < Casa.Length; i++)
            {
                if (Casa[i].IluminacionEncendida == true)
                {
                    encendido = true;
                }
            }
            return encendido;
        }

        //Calcular temperatura promedio de la casa
        public int TemperaturaPromedio(Cuarto[] Casa)
        {
            int suma = 0;
            for (int i = 0; i < Casa.Length; i++)
            {
                suma += Casa[i].Temperatura;
            }
            return suma / Casa.Length;
        }

        //Calcular la humedad promedio de la casa
        public int HumedadPromedio(Cuarto[] Casa)
        {
            int suma = 0;
            for (int i = 0; i < Casa.Length; i++)
            {
                suma += Casa[i].Humedad;
            }
            return suma / Casa.Length;
        }
    }
    //Clase para calefacción
    public class Calefaccion
    {
        //para desplegar el menú calefacción se recibe un vector tipo casa el cual incluye los objetos tipo habitación
        public void MenuCalefaccion(Cuarto[] Casa, int MaxTemp, int MinTemp)
        {
        //Se limpia la pantalla
        LeerCalefaccion:
            Console.Clear();
            Console.WriteLine(@" ,-----.        ,--.        ,---.                    ,--.                ");
            Console.WriteLine(@"'  .--./ ,--,--.|  | ,---. /  .-' ,--,--. ,---. ,---.`--' ,---. ,--,--,  ");
            Console.WriteLine(@"|  |    ' ,-.  ||  || .-. :|  `-,' ,-.  || .--'| .--',--.| .-. ||      \ ");
            Console.WriteLine(@"'  '--'\\ '-'  ||  |\   --.|  .-'\ '-'  |\ `--.\ `--.|  |' '-' '|  ||  | ");
            Console.WriteLine(@" `-----' `--`--'`--' `----'`--'   `--`--' `---' `---'`--' `---' `--''--' ");
            Console.WriteLine("");
            Console.WriteLine("Temperatura actual en los ambientes: ");
            for (int i = 0; i < Casa.Length; i++)
            {
                Console.WriteLine(Casa[i].Nombre + ": " + Casa[i].Temperatura + "°C");
            }
            Console.WriteLine("");
            //imprimir menú de selección de habitaciones
            Console.WriteLine("Ingrese el número de la habitación que desea modificar");
            for (int i = 0; i < Casa.Length; i++)
            {
                Console.WriteLine((i + 1) + "." + Casa[i].Nombre);
            }

            string Nohabitacion = Console.ReadLine();


            //dependiendo de la habitación elegida interactuar
            switch (Nohabitacion)
            {
                case "1":
                    ModificarCalefaccion(Casa[0], MaxTemp, MinTemp);
                    break;
                case "2":
                    ModificarCalefaccion(Casa[1], MaxTemp, MinTemp);
                    break;
                case "3":
                    ModificarCalefaccion(Casa[2], MaxTemp, MinTemp);
                    break;
                case "4":
                    ModificarCalefaccion(Casa[3], MaxTemp, MinTemp);
                    break;
                case "5":
                    ModificarCalefaccion(Casa[4], MaxTemp, MinTemp);
                    break;
                default:
                    Console.WriteLine("Opción inválida, presiona cualquier tecla para ingresar una opción nuevamente");
                    Console.ReadKey();
                    goto LeerCalefaccion;
                    break;
            }
            Console.WriteLine("Presiona cualquier tecla para regresar al menú principal");
            Console.ReadKey();

        }

        //Validar la temperatura del ambiente
        void ModificarCalefaccion(Cuarto cuarto, int MaxTemp, int MinTemp)
        {
            Console.WriteLine("Ingrese la Temperatura actual de la habitación");
            int temperatura = Convert.ToInt32(Console.ReadLine());
            if (temperatura > MaxTemp)
            {
                Console.WriteLine("La temperatura esta sobre el valor deseado el radiador se apagará");
                Console.Beep();
                Console.WriteLine("Apagando...");
                cuarto.CalefaccionEncendida = false;
                cuarto.Temperatura = MaxTemp;
            }
            else if (temperatura <= MaxTemp && temperatura >= MinTemp)
            {
                Console.WriteLine("La temperatura esta en el valor deseado");
                cuarto.CalefaccionEncendida = false;
                cuarto.Temperatura = temperatura;
            }
            else
            {
                Console.WriteLine("La temperatura esta por debajo el valor deseado el radiador se encenderá");
                Console.Beep();
                Console.WriteLine("Encendiendo...");
                cuarto.CalefaccionEncendida = true;
                cuarto.Temperatura = MaxTemp;
            }


        }
    }
}
